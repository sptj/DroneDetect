#pragma once
#include <torch/torch.h> 
torch::Tensor get_anchors(int w, int h);