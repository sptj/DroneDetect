_declspec(dllexport) int   test();
